import java.awt.*;

public class Mentor {
    int CNT = 10;
    double x, y;
    double Vx = 0.1;
    double Vy = 0.1;
    double h, w;
    int type = 1;
    double time = 0;
    double timer = 100;
    double maxE = 100;
    double energy = maxE;
    double maxA = 100;
    double angry = maxA;
    Color color = new Color(0, 0, 0);
    double[][] flags = {{400, 400}, {700, 400}, {700, 700}, {400, 700}};
    int flagN = 0;
    double phi = 90;
    double alph = 20;
    double rr = 1000;

    Mentor(int x, int y, int w, int h, int type) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    Polygon getLight(double x0, double y0, Wall[] walls) {
        int[] poly_x = new int[CNT + 1];
        int[] poly_y = new int[CNT + 1];
        poly_x[0] = (int) (x + x0 + w / 2);
        poly_x[1] = (int) (x + x0 + w / 2 + rr * Math.cos((phi - alph / 2) / 180 * Math.PI));
        poly_x[CNT] = (int) (x + x0 + w / 2 + rr * Math.cos((phi + alph / 2) / 180 * Math.PI));
        poly_y[0] = (int) (y + y0 + h / 2);
        poly_y[1] = (int) (y + y0 + h / 2 + rr * Math.sin((phi - alph / 2) / 180 * Math.PI));
        poly_y[CNT] = (int) (y + y0 + h / 2 + rr * Math.sin((phi + alph / 2) / 180 * Math.PI));

        for (int i = 2; i < CNT; i++) {
            int x = i - 1;
            int y = CNT - 1 - x;
            poly_x[i] = (int) ((poly_x[1] * y + poly_x[CNT] * x) / (double)(x + y));
            poly_y[i] = (int) ((poly_y[1] * y + poly_y[CNT] * x) / (double)(x + y));
        }

        for (Wall wall : walls) {
            if (!wall.live) continue;

            int[] xs = new int[]{(int) (wall.x + x0), (int) (wall.x + x0 + wall.w), (int) (wall.x + x0 + wall.w), (int) (wall.x + x0)};
            int[] ys = new int[]{(int) (wall.y + y0 + wall.h), (int) (wall.y + y0 + wall.h), (int) (wall.y + y0), (int) (wall.y + y0)};

            for (int id = 1; id <= CNT; id++) {
                for (int i = 0; i < 4; i++) {
                    int j = (i + 1) % 4;
                    Geometry.Point intersection = Geometry.getIntersection(poly_x[0], poly_y[0], poly_x[id], poly_y[id], xs[i], ys[i], xs[j], ys[j]);
                    if (intersection != null) {
                        poly_x[id] = (int) intersection.x;
                        poly_y[id] = (int) intersection.y;
                    }
                }
            }
        }

        return new Polygon(poly_x, poly_y, CNT + 1);
    }

    void draw(Graphics g, double x0, double y0, long dt, Wall[] walls) {
        update(g, dt);
        g.setColor(new Color(189, 0, 22, 153));
        Polygon light = getLight(x0, y0, walls);
        g.fillPolygon(light);
        g.setColor(color);
        g.fillRect((int) (x + x0), (int) (y + y0), (int) w, (int) h);
    }

    void update(Graphics g, long dt) {
        System.out.println(phi);
        time += dt;
        if (type == 1) {
            int flagnext = (flagN + 1) % flags.length;
            if (flags[flagN][0] == flags[flagnext][0]) {
                int k = sign(flags[flagN][1] - flags[flagnext][1]);
                phi = -90 * k;
                y += -Vy * k * dt;
                if (k != sign(y - flags[flagnext][1])) {
                    flagN = flagnext;
                    y = flags[flagnext][1];
                }
            } else if (flags[flagN][1] == flags[flagnext][1]) {
                int k = sign(flags[flagN][0] - flags[flagnext][0]);
                phi = 90 + 90 * k;
                x += -Vx * k * dt;
                if (k != sign(x - flags[flagnext][0])) {
                    flagN = flagnext;
                    x = flags[flagnext][0];
                }
            }
        }
    }

    int sign(double x) {
        if (x == 0) {
            return 0;
        }
        if (x > 0) {
            return 1;
        }
        return -1;
    }
}
