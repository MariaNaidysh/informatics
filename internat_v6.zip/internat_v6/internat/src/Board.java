import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static javax.imageio.ImageIO.read;


public class Board {
    boolean lose = false;
    boolean win = false;
    int homework_cnt = 0;
    double x, y;
    Person player;
    Wall[] walls = new Wall[10];
    Predmet[] predmets = new Predmet[100];
    Mentor[] mentors = new Mentor[1];

    Thread music;
    Board(Person person) throws IOException {
        BufferedImage i1 = read(new File("data\\1.png"));
        BufferedImage i2 = read(new File("data\\2.png"));
        BufferedImage i3 = read(new File("data\\3.png"));

        x = 0;
        y = 0;
        player = person;
        walls[0] = new Wall(-1500, -1500, 6000, 1000, 0);
        walls[1] = new Wall(-1500, -1500, 1000, 6000, 0);
        walls[2] = new Wall(-1500, 3500, 6000, 1000, 0);
        walls[3] = new Wall(3500, -1500, 1000, 6000, 0);
        walls[4] = new Wall(2000, 500, 50, 200, 0);
        walls[5] = new Wall(0, 500, 300, 100, 0);
        walls[6] = new Wall(1000, -200, 200, 800, 0);
        walls[7] = new Wall(1500, 1000, 40, 40, 0);
        walls[8] = new Wall(500, 500, 110, 110, 1);
        walls[8].color = new Color(87, 32, 10);
        walls[9] = new Wall(1500, 1500, 300, 110, 2);
        walls[9].color = new Color(0, 197, 172);
        mentors[0] = new Mentor(400, 400, 40, 40, 0);
        mentors[0].color = new Color(75, 72, 72);
        for (int i = 0; i < predmets.length; i++) {
            int XX = 4000;
            int YY = 4000;
            int l = 40;
            int x = (int) (Math.random() * XX);
            int y = (int) (Math.random() * YY);
            if (i < 30) {
                predmets[i] = new Predmet(x, y, l, l, 1, i1);
                predmets[i].color = new Color(119, 120, 229);
            } else if (i >= 30 && i < 70) {
                predmets[i] = new Predmet(x, y, l, l, 2, i2);
                predmets[i].color = new Color(96, 45, 3);
            } else if (i >= 70) {
                predmets[i] = new Predmet(x, y, l, l, 3, i3);
                predmets[i].color = new Color(255, 255, 255);
            }
        }
    }

    void draw(Graphics g, long dt, int window_w, int window_h) {
        g.setColor(new Color(68, 68, 68));
        g.fillRect(0, 0, window_w, window_h);

        if (win) {
            g.setColor(new Color(255, 255, 255));
            g.setFont(new Font("TimesRoman", Font.PLAIN, 50));
            g.drawString("Вы выиграли", window_w / 2 - 175, window_h / 2);
            return;
        }
        if (lose) {
            g.setColor(new Color(255, 255, 255));
            g.setFont(new Font("TimesRoman", Font.PLAIN, 50));
            g.drawString("Вы проиграли", window_w / 2 - 175, window_h / 2);
            return;
        }

        for (int i = 0; i < mentors.length; i++) {
            mentors[i].draw(g, x, y, dt, walls);
        }
        for (int i = 0; i < predmets.length; i++) {
            predmets[i].draw(g, x, y, dt);
        }
        for (int i = 0; i < walls.length; i++) {
            if (walls[i].live) {
                if (player.x - x <= walls[i].x + walls[i].w && player.x + player.w - x >= walls[i].x + walls[i].w && player.y - y < walls[i].y + walls[i].h && player.y + player.h - y > walls[i].y && player.vx < 0) {
                    player.vx = Math.max(0, player.vx);
                    x = player.x - walls[i].x - walls[i].w;
                } else if (player.x + player.w - x >= walls[i].x && player.x - x <= walls[i].x && player.y - y < walls[i].y + walls[i].h && player.y + player.h - y > walls[i].y && player.vx > 0) {
                    player.vx = -Math.max(0, -player.vx);
                    x = player.x + player.w - walls[i].x;
                }
                if (player.y - y <= walls[i].y + walls[i].h && player.y - y >= walls[i].y && player.x - x < walls[i].x + walls[i].w && player.x + player.w - x > walls[i].x) {
                    player.vy = Math.max(0, player.vy);
                    y = player.y - walls[i].y - walls[i].h;
                } else if (player.y + player.h - y >= walls[i].y && player.y + player.h - y <= walls[i].y + walls[i].h && player.x - x < walls[i].x + walls[i].w && player.x + player.w - x > walls[i].x) {
                    player.vy = -Math.max(0, -player.vy);
                    y = player.y - walls[i].y + player.h;
                }
                double x0 = player.x + player.w / 2;
                double y0 = player.y + player.h / 2;

                double x1 = walls[i].x + walls[i].w + x;
                double y1 = walls[i].y + y;
                double x2 = walls[i].x + x;
                double y2 = walls[i].y + walls[i].h + y;

                double xk1 = (x1 - x0) * 100 + x0;
                double yk1 = (y1 - y0) * 100 + y0;
                double xk2 = (x2 - x0) * 100 + x0;
                double yk2 = (y2 - y0) * 100 + y0;
                g.setColor(new Color(38, 38, 38, 255));

                if (walls[i].type == 2) {
                    g.setColor(new Color(38, 38, 38, 0));
                }
                g.fillPolygon(new Polygon(new int[]{(int) (x1), (int) (x2), (int) (xk2), (int) (xk1)}, new int[]{(int) (y1), (int) (y2), (int) (yk2), (int) (yk1)}, 4));

                x1 = walls[i].x + x;
                y1 = walls[i].y + y;
                x2 = walls[i].x + walls[i].w + x;
                y2 = walls[i].y + walls[i].h + y;

                xk1 = (x1 - x0) * 100 + x0;
                yk1 = (y1 - y0) * 100 + y0;
                xk2 = (x2 - x0) * 100 + x0;
                yk2 = (y2 - y0) * 100 + y0;
                g.fillPolygon(new Polygon(new int[]{(int) (x1), (int) (x2), (int) (xk2), (int) (xk1)}, new int[]{(int) (y1), (int) (y2), (int) (yk2), (int) (yk1)}, 4));
            }
            walls[i].draw(g, (int) x, (int) y);
        }

        boolean asleep = false;
        for (Mentor mentor : mentors) {
            Polygon light = mentor.getLight(x, y, walls);
            Point centre = new Point((int) (player.x + player.w / 2), (int) (player.y + player.h / 2));
            asleep |= light.contains(centre);
        }
        player.asleep = asleep;
        if (player.asleep) {
            player.turnLighter = false;
        }

        if(!player.turnLighter) {
            if (music == null) {
                music = new Thread(() -> {
                    new MakeSound().playSound("data\\music.wav");
                });
                music.start();
            }
        } else {
            if (music != null) {
                music.stop();
                music = null;
            }
        }

        update(dt);
        g.setColor(new Color(0, 0, 0, 219));
        if (player.turnLighter) {
            double r = 2500;
            double px = player.x + player.w / 2;
            double py = player.y + player.h / 2;
            double x1 = px + r * Math.cos((player.phi - player.alph / 2) / 180 * Math.PI);
            double y1 = py + r * Math.sin((player.phi - player.alph / 2) / 180 * Math.PI);
            double x2 = px + r * Math.cos((player.phi + player.alph / 2) / 180 * Math.PI);
            double y2 = py + r * Math.sin((player.phi + player.alph / 2) / 180 * Math.PI);
            double x3 = px;
            double y3 = py;
            double x4 = px;
            double y4 = py;
            g.fillPolygon(new Polygon(new int[]{(int) (x1), (int) x3, (int) (2 * px - x4), (int) (2 * px - x3), (int) x4, (int) (x2), (int) (2 * px - x1), (int) (2 * px - x2)}, new int[]{(int) (y1), (int) y3, (int) (2 * py - y4), (int) (2 * py - y3), (int) y4, (int) (y2), (int) (2 * py - y1), (int) (2 * py - y2)}, 8));
        } else {
            g.fillRect(0, 0, window_w, window_h);
        }

        int doorIsNearby = -1;
        for (int i = 0; i < walls.length; i++) {
            double dx = player.x - x + player.w / 2 - walls[i].x - walls[i].w / 2;
            double dy = player.y - y + player.h / 2 - walls[i].y - walls[i].h / 2;
            if (walls[i].type == 1 && Math.sqrt(dx * dx + dy * dy) <= 150) {
                if (walls[i].live) {
                    doorIsNearby = 1;
                } else {
                    doorIsNearby = 2;
                }
            }
        }

        for (int i = 0; i < predmets.length; i++) {
            double dx = player.x - x + player.w / 2 - predmets[i].x - predmets[i].w / 2;
            double dy = player.y - y + player.h / 2 - predmets[i].y - predmets[i].h / 2;
            if (predmets[i].live && Math.sqrt(dx * dx + dy * dy) <= 45) {
                if (predmets[i].type == 1) {
                    player.energy = Math.min(player.energy + 10, player.maxE);
                } else if (predmets[i].type == 2) {
                    player.health = Math.min(player.health + 10, player.maxH);
                } else if (predmets[i].type == 3){
                    homework_cnt += 1;
                }

                predmets[i].live = false;
            }
        }

        g.setColor(new Color(255, 255, 255));
        if (doorIsNearby == 1) {
            g.drawString("Press R to open the door", (int) player.x - 13, (int) player.y);
        } else if (doorIsNearby == 2) {
            g.drawString("Press R to close the door", (int) player.x - 14, (int) player.y);
        }

        player.draw(g, dt);
        if (player.asleep) {
            g.drawString("You are sleeping now", (int) player.x - 8, (int) (player.y + player.h) + 2);
        }

        g.setColor(new Color(255, 255, 255));
        g.drawString("Вы собрали " + homework_cnt + "/30 домашек", 370, 67);

        if (homework_cnt == 30) {
            win = true;
        }
        if (player.energy == 0 || player.health == 0) {
            lose = true;
        }
    }

    void update(long dt) {
        if (player.asleep) return;
        player.vx = player.xR + player.xL;
        player.vy = player.yT + player.yB;
        double len = Math.sqrt(player.vx * player.vx + player.vy * player.vy);
        if (len != 0) {
            x -= player.vx / len * player.v * player.sprint * dt;
            y -= player.vy / len * player.v * player.sprint * dt;
        }
    }
}
