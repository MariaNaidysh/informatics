public class Geometry {
    static public class Point {
        long x, y;
        Point() {
            x = 0;
            y = 0;
        }
        Point(long x, long y) {
            this.x = x;
            this.y = y;
        }
    }

    static public class Line {
        long A, B, C;
        Line() {}
        Line(Point p1, Point p2) {
            A = p1.y - p2.y;
            B = p2.x - p1.x;
            C = - A * p1.x - B * p1.y;
        }
        Line(long x1, long y1, long x2, long y2) {
            A = y1 - y2;
            B = x2 - x1;
            C = - A * x1 - B * y1;
        }
    }

    static boolean isParallel(Line l1, Line l2) {
        return l1.A * l2.B == l2.A * l1.B;
    }

    static Point getLineIntersection(Line l1, Line l2) {
        if (isParallel(l1, l2)) {
            return null;
        }

        double zn = l1.A * l2.B - l2.A * l1.B;
        double x = (l2.C * l1.B - l1.C * l2.B) / zn;
        double y = (l1.C * l2.A - l2.C * l1.A) / zn;

        return new Point((long) x, (long) y);
    }

    static boolean checkInSegmentOnLine(long x1, long y1, long x2, long y2, Point p) {
        return  Math.min(x1, x2) <= p.x && p.x <= Math.max(x1, x2) &&
                Math.min(y1, y2) <= p.y && p.y <= Math.max(y1, y2);
    }
    static Point getIntersection(long x11, long y11, long x12, long y12, long x21, long y21, long x22, long y22) {
        Line l1 = new Line(x11, y11, x12, y12);
        Line l2 = new Line(x21, y21, x22, y22);

        Point p = getLineIntersection(l1, l2);
        if (p == null) {
            return null;
        }

        if (    checkInSegmentOnLine(x11, y11, x12, y12, p) &&
                checkInSegmentOnLine(x21, y21, x22, y22, p) ) {
            return p;
        } else {
            return  null;
        }
    }
}
