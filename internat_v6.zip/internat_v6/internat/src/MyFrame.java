import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferStrategy;
import java.io.File;
import java.io.IOException;

import static javax.imageio.ImageIO.*;

public class MyFrame extends JFrame implements MouseListener, KeyEventDispatcher, MouseMotionListener {

    Person character = new Person(700, 350);
    Boolean SHIFT_PRESSED = false;
    Board board = new Board(character);
    long previousWorldUpdateTime = System.currentTimeMillis();

    public MyFrame() throws IOException {
        setSize(1500, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        addMouseListener(this);
        addMouseMotionListener(this);
        setVisible(true);
        character.image = read(new File("data\\pers.png"));
    }

    @Override
    public void paint(Graphics g) {
        BufferStrategy bufferStrategy = getBufferStrategy();
        if (bufferStrategy == null) {
            createBufferStrategy(2);
            bufferStrategy = getBufferStrategy();
        }
        g = bufferStrategy.getDrawGraphics();
        g.clearRect(0, 0, getWidth(), getHeight());

        long currentTime = System.currentTimeMillis();
        long dt = currentTime - previousWorldUpdateTime;
        board.draw(g, dt, getWidth(), getHeight());
        previousWorldUpdateTime = currentTime;
        g.dispose();
        bufferStrategy.show();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        character.turnLighter = !character.turnLighter;
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_SHIFT && !SHIFT_PRESSED) {
            SHIFT_PRESSED = true;
            character.sprint = 2;
            character.xR *= character.sprint;
            character.xL *= character.sprint;
            character.yT *= character.sprint;
            character.yB *= character.sprint;
        }
        if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_D) {
            character.xR = character.v * character.sprint;
        } else if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_A) {
            character.xL = -character.v * character.sprint;
        } else if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_W) {
            character.yT = -character.v * character.sprint;
        } else if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_S) {
            character.yB = character.v * character.sprint;
        }
        if (e.getID() == KeyEvent.KEY_PRESSED && e.getKeyCode() == KeyEvent.VK_R) {
            for (int i = 0; i < board.walls.length; i++) {
                double dx = board.player.x - board.x + board.player.w / 2 - board.walls[i].x - board.walls[i].w / 2;
                double dy = board.player.y - board.y + board.player.h / 2 - board.walls[i].y - board.walls[i].h / 2;
                if (board.walls[i].type == 1 && Math.sqrt(dx * dx + dy * dy) <= 150) {
                    board.walls[i].live = !board.walls[i].live;
                }
            }
        }
        if (e.getID() == KeyEvent.KEY_RELEASED && e.getKeyCode() == KeyEvent.VK_SHIFT && SHIFT_PRESSED) {
            SHIFT_PRESSED = false;
            character.xR /= character.sprint;
            character.xL /= character.sprint;
            character.yT /= character.sprint;
            character.yB /= character.sprint;
            character.sprint = 1;
        }
        if (e.getID() == KeyEvent.KEY_RELEASED && e.getKeyCode() == KeyEvent.VK_D) {
            character.xR = 0;
        } else if (e.getID() == KeyEvent.KEY_RELEASED && e.getKeyCode() == KeyEvent.VK_A) {
            character.xL = 0;
        } else if (e.getID() == KeyEvent.KEY_RELEASED && e.getKeyCode() == KeyEvent.VK_W) {
            character.yT = 0;
        } else if (e.getID() == KeyEvent.KEY_RELEASED && e.getKeyCode() == KeyEvent.VK_S) {
            character.yB = 0;
        }
        return false;
    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        double dx = e.getX() - character.x - character.w / 2;
        double dy = e.getY() - character.y - character.h / 2;
        if (dx * dx + dy * dy > 200) {
            character.phi = 90 - Math.atan2(dx, dy) * 180 / Math.PI;
        }
    }
}