import java.awt.*;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        MyFrame frame = new MyFrame();
        KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();   // менеджер по трудоустройству слушателей клавиатуры
        manager.addKeyEventDispatcher(frame);
        System.out.println("Start...");

//        new Thread(() -> {
//            new MakeSound().playSound("bip.wav");
//            System.out.println("audio file finished!");
//        }).start();
//
//        System.out.println("main() finished!");
        while (true) {
            frame.repaint();

            // давайте отрисовывать окно не чаще чем раз в 10 миллисекунд - т.е. не чаще чем 100 раз в секунду
            Thread.sleep(15); // для этого ждем 10 миллисекунд прежде чем вновь вызвать frame.repaint();
            // это полезно для того чтобы не грузить процессор компьютера слишком сильно
        }
    }
}