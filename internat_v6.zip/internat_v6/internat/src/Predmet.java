import java.awt.*;
import java.awt.image.BufferedImage;

public class Predmet {
    double x, y;
    double h, w;
    int taked;
    int type; // 1 - red bull, 2 - chokolat, 3 - homework
    boolean live = true;
    Color color = new Color(0, 0, 0);
    BufferedImage image;
    Predmet(int x, int y, int w, int h, int type, BufferedImage image) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.type = type;
        this.image = image;
    }

    void draw(Graphics g, double x0, double y0, long dt) {
        if (live) {
            g.setColor(color);
            g.drawImage(image, (int) (x + x0), (int) (y + y0), (int) w, (int) h, null);
        }
    }
}
