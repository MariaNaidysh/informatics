import java.awt.*;

public class Wall {
    int x, y;
    int h, w;
    int type; //0 - wall, 1 - door, 2 - window
    boolean live = true;
    Color color = new Color(0, 0, 0);

    Wall(int x, int y, int w, int h, int type) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.type = type;
    }

    void draw(Graphics g, double x0, double y0) {
        if (live) {
            g.setColor(color);
        } else {
            g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 150));
        }
        g.fillRect((int) (x + x0), (int) (y + y0), w, h);
    }
}
