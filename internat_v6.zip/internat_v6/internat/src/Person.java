import java.awt.*;
import java.awt.image.BufferedImage;

public class Person {
    Boolean asleep = false;
    double x, y;
    double h, w;
    double vx, vy;
    double v = 0.3;
    double sprint = 1;
    double phi = 0;
    double alph = 120;
    boolean turnLighter = true;

    double xL, xR, yT, yB;
    double vx_n, vy_n;
    double maxH = 100;
    double health = maxH;
    double maxE = 100;
    double energy = maxE;
    boolean stopW = false;

    BufferedImage image;

    Person(double x, double y) {
        this.x = x;
        this.y = y;
        this.h = 100;
        this.w = 100;
        vx = 0;
        vy = 0;
        vx_n = 0;
        vy_n = 0;
    }

    void draw(Graphics g, long dt) {
        update(dt);
        g.drawImage(image, (int) (x), (int) (y), (int) w, (int) h, null);
        g.setColor(new Color(0, 0, 0));
        g.fillRect(0, 0, 350, 100);
        g.setColor(new Color(33, 89, 229));
        g.fillOval(10, 35, 30, 30);
        g.fillRect(27, 40, (int) (300 * health / maxH), 15);
        g.setColor(new Color(33, 89, 229, 142));
        g.fillRect(27, 40, (int) (300), 15);
        g.setColor(new Color(229, 190, 33));
        g.fillOval(10, 65, 30, 30);
        g.fillRect(27, 70, (int) (300 * energy / maxE), 15);
        g.setColor(new Color(229, 190, 33, 152));
        g.fillRect(27, 70, (int) (300), 15);
    }

    void update(long dt) {
        if ((xL + xR != 0 || yT + yB != 0) && !asleep) {
            energy -= 0.001 * dt * sprint;
        } else {
            energy += 0.001 * dt;
            energy = Math.min(energy, maxE);
        }
        if (!turnLighter && !asleep) {
            health -= 0.005 * dt;
        }
        energy = Math.max(0, energy);
        health = Math.max(0, health);
    }


}
